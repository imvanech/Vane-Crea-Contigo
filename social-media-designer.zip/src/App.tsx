import React, { useState } from 'react';
import { ChevronDown, Instagram, Facebook, Linkedin, Twitter, Mail, Phone, MapPin, Star, Menu, X, Eye, Heart, MessageCircle } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activePortfolioCategory, setActivePortfolioCategory] = useState('todos');

  const portfolioItems = [
    {
      id: 1,
      title: "Piezas Gráficas - Suzuki Perú",
      category: "automotriz",
      image: "/images/portfolio-suzuki.jpg",
      description: "Campaña publicitaria para sector automotriz",
      stats: { views: "1.3K", likes: "327", comments: "45" }
    },
    {
      id: 2,
      title: "Brandboard Isla Bonita - Huaral",
      category: "branding",
      image: "/images/portfolio-branding.png",
      description: "Identidad visual para proyecto inmobiliario",
      stats: { views: "1.3K", likes: "131", comments: "28" }
    },
    {
      id: 3,
      title: "Social Media - JAC Camiones",
      category: "automotriz",
      image: "/images/portfolio-jac.jpg",
      description: "Contenido para redes sociales sector automotriz",
      stats: { views: "287", likes: "286", comments: "34" }
    },
    {
      id: 4,
      title: "Agencia Lemon x UPN",
      category: "educativo",
      image: "/images/portfolio-upn.jpg",
      description: "Diseño para eventos educativos universitarios",
      stats: { views: "244", likes: "243", comments: "19" }
    },
    {
      id: 5,
      title: "Pósters Tipográficos",
      category: "tipografia",
      image: "/images/portfolio-typography.jpg",
      description: "Arte tipográfico y lettering creativo",
      stats: { views: "21", likes: "211", comments: "15" }
    },
    {
      id: 6,
      title: "Social Media - PC Speed S.A.C",
      category: "tecnologia",
      image: "/images/portfolio-pcspeed.jpg",
      description: "Contenido para empresa tecnológica",
      stats: { views: "150", likes: "111", comments: "12" }
    }
  ];

  const services = [
    {
      title: "Diseño para Redes Sociales",
      description: "Creación de contenido visual para Instagram, Facebook y LinkedIn que capture la atención y genere engagement.",
      icon: "📱",
      price: "Desde $20"
    },
    {
      title: "Identidad Gráfica",
      description: "Desarrollo de identidad visual completa: logotipos, paletas de colores, tipografías y brandboards.",
      icon: "🎨",
      price: "Desde $50"
    },
    {
      title: "Piezas Gráficas",
      description: "Diseño de materiales promocionales, flyers, banners y contenido gráfico para campañas.",
      icon: "🖼️",
      price: "Desde $30"
    },
    {
      title: "Diseño Tipográfico",
      description: "Creación de pósters tipográficos y lettering creativo para proyectos especiales.",
      icon: "✍️",
      price: "Desde $40"
    },
    {
      title: "Branding Inmobiliario",
      description: "Especialización en identidad visual para proyectos inmobiliarios y desarrollo de brandboards.",
      icon: "🏢",
      price: "Desde $80"
    },
    {
      title: "Diseño Automotriz",
      description: "Creación de contenido especializado para sector automotriz y campañas de vehículos.",
      icon: "🚗",
      price: "Desde $60"
    }
  ];

  const testimonials = [
    {
      name: "Director Comercial",
      company: "Sector Automotriz",
      text: "El trabajo de Vanessa para nuestra campaña fue excepcional. Su creatividad y profesionalismo destacaron en cada pieza gráfica.",
      rating: 5,
      avatar: "DC"
    },
    {
      name: "Coordinador de Marketing",
      company: "Universidad Privada",
      text: "Estoy agradecido por formar parte de este proyecto. Vanessa demostró un gran compromiso con cada evento educativo que diseñamos.",
      rating: 5,
      avatar: "CM"
    },
    {
      name: "Gerente de Proyecto",
      company: "Desarrollo Inmobiliario",
      text: "El brandboard que creó captó perfectamente la calidez y tranquilidad que queríamos transmitir para nuestro proyecto.",
      rating: 5,
      avatar: "GP"
    },
    {
      name: "Director Creativo",
      company: "Agencia de Marketing",
      text: "Vanessa tiene un talento especial para el diseño tipográfico. Sus pósters son verdaderas obras de arte visual.",
      rating: 5,
      avatar: "DC"
    }
  ];

  const filteredPortfolio = activePortfolioCategory === 'todos' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activePortfolioCategory);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Vane Crea Contigo
              </h1>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <button onClick={() => scrollToSection('hero')} className="text-gray-700 hover:text-purple-600 transition-colors">Inicio</button>
                <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-purple-600 transition-colors">Sobre Mí</button>
                <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-purple-600 transition-colors">Servicios</button>
                <button onClick={() => scrollToSection('portfolio')} className="text-gray-700 hover:text-purple-600 transition-colors">Portafolio</button>
                <button onClick={() => scrollToSection('testimonials')} className="text-gray-700 hover:text-purple-600 transition-colors">Testimonios</button>
                <button onClick={() => scrollToSection('contact')} className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full hover:shadow-lg transition-all">Contacto</button>
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-700 hover:text-purple-600"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-gray-100">
                <button onClick={() => scrollToSection('hero')} className="block text-gray-700 hover:text-purple-600 px-3 py-2">Inicio</button>
                <button onClick={() => scrollToSection('about')} className="block text-gray-700 hover:text-purple-600 px-3 py-2">Sobre Mí</button>
                <button onClick={() => scrollToSection('services')} className="block text-gray-700 hover:text-purple-600 px-3 py-2">Servicios</button>
                <button onClick={() => scrollToSection('portfolio')} className="block text-gray-700 hover:text-purple-600 px-3 py-2">Portafolio</button>
                <button onClick={() => scrollToSection('testimonials')} className="block text-gray-700 hover:text-purple-600 px-3 py-2">Testimonios</button>
                <button onClick={() => scrollToSection('contact')} className="block text-gray-700 hover:text-purple-600 px-3 py-2">Contacto</button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className="pt-16 min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50 flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Diseñadora de
              <span className="block bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Redes Sociales
              </span>
              <span className="block text-3xl md:text-4xl">Creativa</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl">
              Explorando el mundo a través del diseño digital. Especializada en identidad gráfica y diseño para redes sociales, 
              transformo ideas en experiencias visuales que conectan marcas con sus audiencias.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button 
                onClick={() => scrollToSection('portfolio')}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all"
              >
                Ver Mi Trabajo
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="border-2 border-purple-600 text-purple-600 px-8 py-4 rounded-full text-lg font-semibold hover:bg-purple-600 hover:text-white transition-all"
              >
                Trabajemos Juntos
              </button>
            </div>
            <div className="mt-12 flex justify-center lg:justify-start space-x-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">12+</div>
                <div className="text-gray-600">Proyectos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-600">65</div>
                <div className="text-gray-600">Apreciaciones</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-600">9</div>
                <div className="text-gray-600">Años</div>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="relative z-10">
              <img 
                src="/images/hero-designer.jpg" 
                alt="Diseñadora trabajando"
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
            </div>
            <div className="absolute -top-4 -right-4 w-full h-full bg-gradient-to-br from-purple-200 to-pink-200 rounded-2xl -z-10"></div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img 
                src="/images/about-workspace.jpg" 
                alt="Espacio de trabajo creativo"
                className="rounded-2xl shadow-xl w-full h-96 object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white font-bold">
                    V
                  </div>
                  <div>
                    <div className="font-semibold">Vanessa Echenagucia</div>
                    <div className="text-gray-600">Graphic Designer</div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Sobre <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Mí</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Soy Vanessa Echenagucia, diseñadora gráfica con sede en Santiago, Chile. Con más de 9 años de experiencia 
                desde 2015, me especializo en explorar el mundo a través del diseño digital, creando experiencias visuales 
                que conectan marcas con sus audiencias.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                He trabajado con marcas reconocidas como Suzuki Perú, JAC Camiones, UPN (Universidad Privada del Norte), 
                y PC Speed, desarrollando proyectos que van desde branding inmobiliario hasta campañas automotrices. 
                Mi enfoque combina creatividad estratégica con herramientas profesionales de Adobe Creative Cloud.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <span className="text-purple-600 font-bold">✓</span>
                  </div>
                  <span className="text-gray-700">9+ años de experiencia en diseño gráfico (desde 2015)</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <span className="text-purple-600 font-bold">✓</span>
                  </div>
                  <span className="text-gray-700">Adobe Creative Cloud: Illustrator, Photoshop, InDesign</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <span className="text-purple-600 font-bold">✓</span>
                  </div>
                  <span className="text-gray-700">Experiencia en sectores automotriz, inmobiliario y educativo</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <span className="text-purple-600 font-bold">✓</span>
                  </div>
                  <span className="text-gray-700">Actualizada con las últimas tendencias</span>
                </div>
              </div>

              <div className="mt-8 flex space-x-4">
                <a href="#" className="text-purple-600 hover:text-purple-800 transition-colors">
                  <Instagram size={24} />
                </a>
                <a href="#" className="text-purple-600 hover:text-purple-800 transition-colors">
                  <Linkedin size={24} />
                </a>
                <a href="#" className="text-purple-600 hover:text-purple-800 transition-colors">
                  <Twitter size={24} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Mis <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Servicios</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Ofrezco soluciones integrales de diseño para redes sociales que impulsan el crecimiento 
              de tu marca y conectan con tu audiencia objetivo.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-2">
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {service.price}
                  </span>
                  <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-full text-sm hover:shadow-lg transition-all">
                    Más Info
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Mi <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Portafolio</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Explora algunos de mis trabajos más destacados y descubre cómo he ayudado a marcas 
              a destacar en el competitivo mundo de las redes sociales.
            </p>

            {/* Portfolio Filter */}
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {[
                { id: 'todos', label: 'Todos' },
                { id: 'instagram', label: 'Instagram' },
                { id: 'stories', label: 'Stories' },
                { id: 'branding', label: 'Branding' },
                { id: 'linkedin', label: 'LinkedIn' },
                { id: 'facebook', label: 'Facebook' },
                { id: 'campanas', label: 'Campañas' }
              ].map((category) => (
                <button
                  key={category.id}
                  onClick={() => setActivePortfolioCategory(category.id)}
                  className={`px-6 py-2 rounded-full transition-all ${
                    activePortfolioCategory === category.id
                      ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {category.label}
                </button>
              ))}
            </div>
          </div>

          {/* Portfolio Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPortfolio.map((item) => (
              <div key={item.id} className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                    <p className="text-gray-300 mb-4">{item.description}</p>
                    <div className="flex items-center space-x-4 text-sm">
                      <div className="flex items-center space-x-1">
                        <Eye size={16} />
                        <span>{item.stats.views}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Heart size={16} />
                        <span>{item.stats.likes}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MessageCircle size={16} />
                        <span>{item.stats.comments}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Lo Que Dicen Mis <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Clientes</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              La satisfacción de mis clientes es mi mayor recompensa. Descubre por qué eligen trabajar conmigo.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={20} className="text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white font-bold">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-gray-500 text-sm">{testimonial.company}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              ¿Listo Para <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Trabajar Juntos?</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Cuéntame sobre tu proyecto y hagamos que tu marca destaque en redes sociales.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-2xl">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Envíame un Mensaje</h3>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Nombre</label>
                    <input 
                      type="text"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                      placeholder="Tu nombre"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Email</label>
                    <input 
                      type="email"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Tipo de Proyecto</label>
                  <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent">
                    <option>Selecciona un servicio</option>
                    <option>Diseño de Posts</option>
                    <option>Stories & Highlights</option>
                    <option>Branding Visual</option>
                    <option>Estrategia de Contenido</option>
                    <option>Plantillas Personalizadas</option>
                    <option>Gestión de Campañas</option>
                  </select>
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Mensaje</label>
                  <textarea 
                    rows={5}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                    placeholder="Cuéntame sobre tu proyecto..."
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-4 rounded-lg font-semibold hover:shadow-lg transform hover:scale-105 transition-all"
                >
                  Enviar Mensaje
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Información de Contacto</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                      <Mail className="text-purple-600" size={20} />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Email</div>
                      <div className="text-gray-600">ana@anadesigns.com</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                      <Phone className="text-purple-600" size={20} />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Teléfono</div>
                      <div className="text-gray-600">+34 123 456 789</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                      <MapPin className="text-purple-600" size={20} />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Ubicación</div>
                      <div className="text-gray-600">Madrid, España</div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Sígueme en Redes Sociales</h4>
                <div className="flex space-x-4">
                  <a href="#" className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white hover:shadow-lg transition-all">
                    <Instagram size={20} />
                  </a>
                  <a href="#" className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white hover:shadow-lg transition-all">
                    <Facebook size={20} />
                  </a>
                  <a href="#" className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white hover:shadow-lg transition-all">
                    <Linkedin size={20} />
                  </a>
                  <a href="#" className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center text-white hover:shadow-lg transition-all">
                    <Twitter size={20} />
                  </a>
                </div>
              </div>

              <div className="bg-gradient-to-br from-purple-100 to-pink-100 p-6 rounded-2xl">
                <h4 className="text-lg font-semibold text-gray-900 mb-3">¿Tienes un Proyecto Urgente?</h4>
                <p className="text-gray-600 mb-4">
                  Si necesitas resultados rápidos, ofrezco servicios express con entrega en 24-48 horas.
                </p>
                <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg transition-all">
                  Consultar Express
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
                Ana Designs
              </h3>
              <p className="text-gray-400">
                Creando experiencias visuales que conectan marcas con sus audiencias en el mundo digital.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Servicios</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Diseño de Posts</li>
                <li>Stories & Highlights</li>
                <li>Branding Visual</li>
                <li>Estrategia de Contenido</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Enlaces</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => scrollToSection('about')}>Sobre Mí</button></li>
                <li><button onClick={() => scrollToSection('portfolio')}>Portafolio</button></li>
                <li><button onClick={() => scrollToSection('testimonials')}>Testimonios</button></li>
                <li><button onClick={() => scrollToSection('contact')}>Contacto</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contacto</h4>
              <ul className="space-y-2 text-gray-400">
                <li>ana@anadesigns.com</li>
                <li>+34 123 456 789</li>
                <li>Madrid, España</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Ana Designs. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
