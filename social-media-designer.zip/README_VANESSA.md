# 🎨 Página Web de Vanessa Echenagucia - Vane Crea Contigo

## 🌐 Información del Sitio

- **Diseñadora:** Vanessa Echenagucia
- **Marca:** Vane Crea Contigo  
- **Ubicación:** Santiago, Chile
- **Especialidad:** Diseño Gráfico para Redes Sociales e Identidad de Marca
- **URL del Sitio:** https://me9bzvvqz6.space.minimax.io

## ✨ Características de la Página Web

### Secciones Incluidas
1. **Hero/Inicio** - Presentación principal con estadísticas
2. **Sobre Mí** - Biografía y experiencia profesional
3. **Servicios** - 6 servicios principales con precios
4. **Portafolio** - Galería de proyectos reales con filtros
5. **Testimonios** - Comentarios de clientes por sector
6. **Contacto** - Formulario funcional

### Información Personal Real
- ✅ **Experiencia:** 9 años (desde 2015)
- ✅ **Herramientas:** Adobe Illustrator, Photoshop, InDesign
- ✅ **Sectores:** Automotriz, Inmobiliario, Educativo, Tecnológico
- ✅ **Clientes destacados:** Suzuki Perú, JAC Camiones, UPN, PC Speed

### Servicios y Precios
1. **Diseño para Redes Sociales** - Desde $20 USD
2. **Identidad Gráfica** - Desde $50 USD
3. **Piezas Gráficas** - Desde $30 USD
4. **Diseño Tipográfico** - Desde $40 USD
5. **Branding Inmobiliario** - Desde $80 USD
6. **Diseño Automotriz** - Desde $60 USD

### Proyectos Destacados en Portafolio
1. **Piezas Gráficas - Suzuki Perú** (327 apreciaciones)
2. **Brandboard Isla Bonita - Huaral** (131 apreciaciones)
3. **Social Media - JAC Camiones** (286 apreciaciones)
4. **Agencia Lemon x UPN** (243 apreciaciones)
5. **Pósters Tipográficos** (211 apreciaciones)
6. **Social Media - PC Speed S.A.C** (111 apreciaciones)

## 🛠️ Tecnologías Utilizadas

- **Framework:** React 18 + TypeScript
- **Estilos:** TailwindCSS
- **Build Tool:** Vite
- **Iconos:** Lucide React
- **Deployment:** Hosting estático gratuito

## 📁 Estructura del Proyecto

```
social-media-designer/
├── public/
│   ├── images/                 # Imágenes del portafolio
│   └── index.html             # HTML base
├── src/
│   ├── App.tsx                # 🎯 COMPONENTE PRINCIPAL
│   ├── index.css              # Estilos globales TailwindCSS
│   └── main.tsx               # Punto de entrada
├── dist/                      # Build de producción
├── package.json               # Dependencias del proyecto
├── tailwind.config.js         # Configuración de TailwindCSS
└── vite.config.ts            # Configuración de Vite
```

## 🎨 Personalización Rápida

### Cambiar Colores Principales
Los colores se definen en TailwindCSS:
- **Primario:** `purple-600` (morado)
- **Secundario:** `pink-600` (rosa)
- **Acento:** `yellow-600` (amarillo)

### Editar Contenido Principal
Todo el contenido está en `src/App.tsx`:

```javascript
// Cambiar servicios
const services = [
  {
    title: "Tu servicio",
    description: "Tu descripción",
    price: "Tu precio"
  }
];

// Cambiar proyectos del portafolio
const portfolioItems = [
  {
    title: "Tu proyecto",
    category: "categoria",
    description: "Descripción del proyecto"
  }
];
```

### Actualizar Información Personal
Busca y reemplaza en `App.tsx`:
- `"Vanessa Echenagucia"` - Nombre
- `"Santiago, Chile"` - Ubicación  
- `"Vane Crea Contigo"` - Nombre de la marca
- Biografía en la sección "Sobre Mí"

## 🖼️ Gestión de Imágenes

### Imágenes Necesarias (en `public/images/`)
- `hero-designer.jpg` - Foto principal (400x400px recomendado)
- `about-workspace.jpg` - Espacio de trabajo (600x400px)
- `portfolio-*.jpg` - Imágenes de proyectos (400x300px)

### Optimización de Imágenes
- **Formato:** JPG para fotos, PNG para gráficos
- **Tamaño:** Máximo 1MB por imagen
- **Resolución:** 72 DPI para web

## 🚀 Comandos de Desarrollo

```bash
# Instalar dependencias
npm install

# Servidor de desarrollo
npm run dev

# Construir para producción
npm run build

# Vista previa del build
npm run preview
```

## 🌐 Opciones de Deployment Gratuito

### 1. Netlify (Recomendado)
1. Conecta tu repositorio de GitHub
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Deploy automático en cada commit

### 2. Vercel
1. Conecta con GitHub
2. Importa el proyecto
3. Deploy automático

### 3. GitHub Pages
1. Build el proyecto: `npm run build`
2. Sube la carpeta `dist` a GitHub
3. Habilita GitHub Pages

## 📱 Responsive Design

La página está optimizada para:
- ✅ **Desktop** (1920px+)
- ✅ **Laptop** (1024px)
- ✅ **Tablet** (768px)
- ✅ **Mobile** (375px+)

## 🔧 Personalización Avanzada

### Agregar Nueva Sección
1. Crea el componente en `App.tsx`
2. Agrega la navegación correspondiente
3. Aplica los estilos con TailwindCSS

### Cambiar Tipografía
En `tailwind.config.js`:
```javascript
theme: {
  extend: {
    fontFamily: {
      'sans': ['Tu fuente', 'system-ui']
    }
  }
}
```

### Agregar Animaciones
TailwindCSS incluye animaciones básicas:
- `animate-bounce`
- `animate-pulse`
- `animate-spin`

## 📊 SEO y Rendimiento

### Meta Tags (en `index.html`)
```html
<title>Vanessa Echenagucia - Diseñadora Gráfica | Vane Crea Contigo</title>
<meta name="description" content="Diseñadora gráfica especializada en redes sociales e identidad de marca. 9 años de experiencia.">
```

### Optimizaciones Incluidas
- ✅ **Code splitting** automático
- ✅ **CSS minificado**
- ✅ **Imágenes lazy loading**
- ✅ **Diseño responsive**

## 🆘 Solución de Problemas

### Build Errors
```bash
# Limpiar cache
rm -rf node_modules dist
npm install
npm run build
```

### Problemas de Estilos
1. Verifica la sintaxis de TailwindCSS
2. Reconstruye el proyecto
3. Revisa que no hayas eliminado clases necesarias

### Imágenes No Cargan
1. Verifica rutas en `public/images/`
2. Nombres de archivo exactos
3. Formato de imagen compatible

## 📈 Métricas y Analytics

### Para agregar Google Analytics:
1. Obtén tu código de seguimiento
2. Agrégalo en `public/index.html`
3. O usa una biblioteca como `react-ga4`

### Métricas Importantes a Seguir:
- Tiempo en página
- Tasa de rebote
- Conversiones de formulario de contacto
- Páginas más visitadas

## 💼 Próximas Mejoras Sugeridas

1. **Blog/Noticias** - Agregar sección de artículos
2. **Calculadora de Precios** - Herramienta interactiva
3. **Calendario de Disponibilidad** - Integración con Calendly
4. **Chat en Vivo** - Widget de WhatsApp
5. **Galería Expandida** - Más proyectos con lightbox

---

**🎯 Esta página web está lista para uso profesional y completamente optimizada para convertir visitantes en clientes.**

**🔗 URL del Sitio:** https://me9bzvvqz6.space.minimax.io
